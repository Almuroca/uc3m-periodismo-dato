# APUNTES 21 DE SEPTIEMBRE 2021

## TIPOS DE VALORES

1. (*SV): valores separados por cualquier cosa
2. TSV: valores separados por tabulador
3. CSV: valores separados por comas

## FORMATOS DE DATOS

1. (*SV): valores separados por cualquier cosa
2. JSON
3. XML

## TIPOS DE DATOS PARA TABLAS CSV

- Números: decimales que afecta al mundo CSV por las comas y los puntos.
- Date: YYYY-MM-DD
- Booleanos: dos opciones
- Lenguaje strings: cadena de caracteres

## GUARDAR CARACTERES

ASC II, ISO - 8859- 1.15, UTF-8 = UNICODE.
Es complicado porque al guardar tiene que tener esa descodificación de caracteres.

## FUNCIONES

- JOIN (): columna nueva mezclando otra. 
- UPPERCASE (): mayúsculas
- LOWERCASE (): minúsculas
- CAPITALLETTERCASE (): primera en mayúscula y el resto minúsculas. 
