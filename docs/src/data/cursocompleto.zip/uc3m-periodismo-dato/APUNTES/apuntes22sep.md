# CLASE 22 DE SEPTIEMBRE DE 2021

## APRENDER A PARTIR DE TABLA DE DATOS:

- Tabla es representación visual de un /*SV*/, un archivo de valores separados por comas.
- Se lee de dch a izq y de arriba  a abajo. 

## TIPOS DE DATOS:

### NUMÉRICOS
1. Integer: sin decimales, números enteros. Cuidado con los millares porque distraen, así pues tenemos el OPENREFINE para quitar los caracteres de puntos o comas de millar.
2. Decimales: decimales pero sin muchos decimales y siempre mismo número. (un par de ellos)
3. Float or double: tienen más decimales. 
4. Date or datetime: YYYY-MM-DD. Se añade la T de tiempo. Z es horario universal es el de Canarias.
5. Period: se pueden poner en negativo. 

### Strings: valores que quieras

### Booleanos: una opción u otra.
