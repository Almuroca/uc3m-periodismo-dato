# API BASH

- STDIN: entrada
- STDOUT: salida
- STDERR: salida de errores

## COMANDOS

1. **cat** &rarr; visor de lo que has descargado
2. **less** &rarr; para paginar
3. **>** &rarr; le dices que en vez de pantalla la manda a un archivo.
4. **q** &rarr; salir, te vas de lo que esté puesto
5. **|** &rarr; comando pasa como entrada de datos al comando siguiente que es less que es un paginador, es como pasar de una acción a otra de manera concatenada. 
