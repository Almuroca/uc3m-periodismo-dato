# CONECTAR GITHUB AL ORDENADOR

1. Instalar Git. 
2. GIT está entre GH (Github) y nuestro ordenador. 


## THE GUARDIAN, rutas absolutas y relativas.

1. The Guardian, hay un punto cero y cosas por arriba: PARENT y por abajo: CHILD. Detrás del punto 0 está us-news, luego 2021, después septiembre, otra rama sería el día y otra la noticia en sí.
2. Rutas absolutas: directorio completo. Relativa: ir de una noticia a otra: a href="noticia". 

## DATOS TERMINAL

pwd: nos dice quiénes somos. 
~~TACHADO~~

## COMANDOS

pwd
ls
cd
git clone URL nombre
git remote -v
