# COMANDOS

- ls: listar
- ls -l: listar más datos con permisos, propietario, listar de forma completa.
- ls -a: muestra los archivos ocultos. 
- pwd: te dice dónde estás. 
- mkdir: crear un directorio
- cd: cambiar de directorio 
- >: pedimos que mande a un archivo
- >>: los junta, no los reemplaza
- * es el comodín. 
- file: tipo de archivo.
- du -sh: qué cantidad hay. 
- wc -l: líneas que tiene.
- head: muestra las diez primeras líneas. 
- tail: los últimos. 
