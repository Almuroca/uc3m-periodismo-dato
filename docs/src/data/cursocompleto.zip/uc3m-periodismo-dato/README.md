# Periodismo de Datos en UC3M

Notas sobre **Periodismo de Datos** en *UC3M*

## Qué es el periodismo de datos 
- Periodismo
- Visualización
- Datos

## HTTP
Es una _API_ que tiene cuatro tareas posibles:
1. POST
2. GET
3. DELETE
4. PUT
